#!/bin/bash
java -jar ACE-XCSP24.jar "$1" -varh=FrbaOnDom